package com.wahoofitness.samples.apisampleapp.ui;

import android.app.Activity;
import android.os.Bundle;

import com.wahoofitness.samples.apisampleapp.R;

public class DiscoverActivity extends Activity {

	@Override
	protected void onCreate(Bundle savedInstanceState) {
		super.onCreate(savedInstanceState);
		setContentView(R.layout.discover_activity);

	}

}
